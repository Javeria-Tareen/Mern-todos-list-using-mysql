// app.js
const express = require('express');
const bodyParser = require('body-parser');
const todoRoutes = require('./routes/todoRoutes');  // Import the todo routes
const config = require('./config/config');  // Import configuration
const cors = require('cors');       // Import cors

const app = express();              // Initialize express
app.use(cors());                    // Use cors middleware


// Middleware to parse incoming requests with JSON payloads
app.use(bodyParser.json());

// Set up the API routes
app.use('/api', todoRoutes);

// Default route for testing
app.get('/', (req, res) => {
  res.send('To-Do API is working!');
});

module.exports = app;  // Export the app for use in server.js
