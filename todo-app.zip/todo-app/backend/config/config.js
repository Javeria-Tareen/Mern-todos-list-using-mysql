module.exports = {
  PORT: 5000,          // Port for the server to run on
  DB_HOST: 'localhost', // Database host (assuming MySQL is running locally)
  DB_USER: 'root',      // MySQL username
  DB_PASSWORD: '1234', // MySQL password
  DB_NAME: 'mern_todo_app'    // The database name
};
