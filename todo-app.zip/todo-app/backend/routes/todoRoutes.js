const express = require('express');
const router = express.Router();
const todoController = require('../controllers/todoController');  // Import the controller

// Get all todos
router.get('/todos', todoController.getTodos);

// Add a new todo
router.post('/todos', todoController.addTodo);

// Update an existing todo by ID
router.put('/todos/:id', todoController.updateTodo);

// Delete a todo by ID
router.delete('/todos/:id', todoController.deleteTodo);

module.exports = router;  // Export the routes for use in the main app
