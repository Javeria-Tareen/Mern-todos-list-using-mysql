const db = require('../config/db');

// Get all todos
exports.getTodos = (req, res) => {
  const query = 'SELECT * FROM todos ORDER BY id DESC';  // Fetch all todos and order by id descending
  
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error retrieving todos:', err);
      return res.status(500).json({ error: 'Failed to retrieve todos' });
    }
    res.json(results);  // Send the retrieved todos as JSON
  });
};

// Add a new todo
exports.addTodo = (req, res) => {
  const { title, description, status } = req.body;
  
  // Check if title and description are provided
  if (!title || !description || !status) {
    return res.status(400).json({ error: 'Title, description, and status are required' });
  }

  const query = 'INSERT INTO todos (title, description, status) VALUES (?, ?, ?)';

  db.query(query, [title, description, status], (err, results) => {
    if (err) {
      console.error('Error adding todo:', err);
      return res.status(500).json({ error: 'Failed to add todo' });
    }
    res.status(201).json({ message: 'Todo added successfully', todoId: results.insertId });
  });
};

// Update a todo
exports.updateTodo = (req, res) => {
  const { id } = req.params;
  const { title, description, status } = req.body;

  // Check if the todo exists
  const checkQuery = 'SELECT * FROM todos WHERE id = ?';
  db.query(checkQuery, [id], (err, result) => {
    if (err) {
      console.error('Error checking todo:', err);
      return res.status(500).json({ error: 'Failed to check todo' });
    }
    if (result.length === 0) {
      return res.status(404).json({ error: 'Todo not found' });
    }

    // Proceed with updating the todo
    const updateQuery = 'UPDATE todos SET title = ?, description = ?, status = ? WHERE id = ?';
    db.query(updateQuery, [title, description, status, id], (err, results) => {
      if (err) {
        console.error('Error updating todo:', err);
        return res.status(500).json({ error: 'Failed to update todo' });
      }
      res.json({ message: 'Todo updated successfully' });
    });
  });
};

// Delete a todo
exports.deleteTodo = (req, res) => {
  const { id } = req.params;

  // Check if the todo exists
  const checkQuery = 'SELECT * FROM todos WHERE id = ?';
  db.query(checkQuery, [id], (err, result) => {
    if (err) {
      console.error('Error checking todo:', err);
      return res.status(500).json({ error: 'Failed to check todo' });
    }
    if (result.length === 0) {
      return res.status(404).json({ error: 'Todo not found' });
    }

    // Proceed with deleting the todo
    const deleteQuery = 'DELETE FROM todos WHERE id = ?';
    db.query(deleteQuery, [id], (err, results) => {
      if (err) {
        console.error('Error deleting todo:', err);
        return res.status(500).json({ error: 'Failed to delete todo' });
      }
      res.json({ message: 'Todo deleted successfully' });
    });
  });
};
