// tailwind.config.js
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{html,js}", // Adjust for your project's file paths
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
