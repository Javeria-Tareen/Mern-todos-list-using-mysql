import axios from 'axios';

// Base URL of your API
const API_URL = 'http://localhost:5000/api/todos';

// Get all todos
const getTodos = async () => {
  try {
    const response = await axios.get(API_URL);
    return response.data;  // Return the todos fetched from the backend
  } catch (error) {
    console.error('Error fetching todos:', error.response ? error.response.data : error.message);
    throw error;  // Throw the error to be handled where the function is called
  }
};

// Add a new todo
const addTodo = async (todo) => {
  try {
    const response = await axios.post(API_URL, todo, {
      headers: {
        'Content-Type': 'application/json',  // Ensure the content type is set for POST requests
      }
    });
    return response.data;  // Return the data of the newly added todo
  } catch (error) {
    console.error('Error adding todo:', error.response ? error.response.data : error.message);
    throw error;
  }
};

// Update an existing todo
const updateTodo = async (id, todo) => {
  try {
    const response = await axios.put(`${API_URL}/${id}`, todo, {
      headers: {
        'Content-Type': 'application/json',  // Ensure the content type is set for PUT requests
      }
    });
    return response.data;  // Return the updated todo
  } catch (error) {
    console.error('Error updating todo:', error.response ? error.response.data : error.message);
    throw error;
  }
};

// Delete a todo by ID
const deleteTodo = async (id) => {
  try {
    const response = await axios.delete(`${API_URL}/${id}`);
    return response.data;  // Return the response confirming deletion
  } catch (error) {
    console.error('Error deleting todo:', error.response ? error.response.data : error.message);
    throw error;
  }
};

export { getTodos, addTodo, updateTodo, deleteTodo };
