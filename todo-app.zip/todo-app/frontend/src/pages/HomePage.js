import React from 'react';
import TodoList from '../components/TodoList';

const HomePage = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <div className="w-full max-w-3xl bg-white shadow-lg rounded-lg overflow-hidden">
        {/* Header Section */}
        <div className="bg-indigo-600 text-white p-6 text-center">
          <h1 className="text-3xl font-semibold">Todo List</h1>
          <p className="mt-2 text-lg">Keep track of your tasks and stay organized.</p>
        </div>

        {/* Main Content */}
        <div className="p-8">
          <TodoList />
        </div>

        {/* Footer Section */}
        <div className="bg-gray-200 p-4 text-center">
          <p className="text-sm text-gray-600">© 2025 Your Todo App. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
