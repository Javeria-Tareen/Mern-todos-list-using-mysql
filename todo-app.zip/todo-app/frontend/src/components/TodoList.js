import React, { useState, useEffect } from 'react';
import { getTodos } from '../api';  // Adjust the path based on where api.js is located
import TodoItem from './TodoItem';
import AddTodo from './AddTodo';

const TodoList = () => {
  const [todos, setTodos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Fetch todos from the backend
  const fetchTodos = async () => {
    setLoading(true);
    setError('');
    try {
      const fetchedTodos = await getTodos();
      setTodos(fetchedTodos);
    } catch (error) {
      console.error('Error fetching todos:', error);
      setError('Failed to load todos. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Add a new todo to the list
  const handleAddTodo = (newTodo) => {
    setTodos((prevTodos) => [...prevTodos, newTodo]);
  };

  // Update a todo in the list
  const handleUpdateTodo = (updatedTodo) => {
    setTodos((prevTodos) =>
      prevTodos.map((todo) =>
        todo.id === updatedTodo.id ? updatedTodo : todo
      )
    );
  };

  // Delete a todo from the list
  const handleDeleteTodo = (id) => {
    setTodos((prevTodos) => prevTodos.filter((todo) => todo.id !== id));
  };

  // Fetch todos when the component mounts
  useEffect(() => {
    fetchTodos();
  }, []);

  return (
    <div className="max-w-4xl mx-auto p-4">
      <AddTodo onAddTodo={handleAddTodo} />

      <h3 className="text-2xl font-semibold text-gray-800 mt-6 mb-4 text-center">Todo List</h3>

      {loading ? (
        <p className="text-blue-600 text-center">Loading todos...</p>
      ) : error ? (
        <p className="text-red-600 text-center">{error}</p>
      ) : todos.length > 0 ? (
        todos.map((todo) => (
          <TodoItem
            key={todo.id}
            todo={todo}
            onUpdateTodo={handleUpdateTodo}
            onDeleteTodo={handleDeleteTodo}
          />
        ))
      ) : (
        <p className="text-gray-600 text-center">No todos available</p>
      )}
    </div>
  );
};

export default TodoList;
