import React from 'react';

const Navbar = () => {
  return (
    <nav className="bg-indigo-600 text-white p-4 shadow-md">
      <div className="max-w-7xl mx-auto flex justify-center items-center">
        <h2 className="text-3xl font-semibold">To-Do List</h2>
      </div>
    </nav>
  );
};

export default Navbar;
