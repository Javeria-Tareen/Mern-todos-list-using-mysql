import React, { useState } from 'react';
import { updateTodo, deleteTodo } from '../api'; // Adjust the path based on where api.js is located

const TodoItem = ({ todo, onUpdateTodo, onDeleteTodo }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(todo.title);
  const [editDescription, setEditDescription] = useState(todo.description);
  const [isProcessing, setIsProcessing] = useState(false); // Disable buttons during actions
  const [error, setError] = useState('');

  if (!todo) {
    console.error('Todo object is undefined:', todo);
    return null;
  }

  // Optimistic status update
  const handleUpdate = async () => {
    const originalStatus = todo.status;
    const updatedTodo = { ...todo, status: todo.status === 'pending' ? 'completed' : 'pending' };

    setIsProcessing(true);
    onUpdateTodo(updatedTodo); // Immediate UI update

    try {
      await updateTodo(todo.id, updatedTodo);
    } catch (error) {
      console.error('Error updating todo:', error);
      onUpdateTodo({ ...todo, status: originalStatus }); // Revert on error
      setError('Failed to update status. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Optimistic delete
  const handleDelete = async () => {
    setIsProcessing(true);
    onDeleteTodo(todo.id); // Immediate UI removal

    try {
      await deleteTodo(todo.id);
    } catch (error) {
      console.error('Error deleting todo:', error);
      setError('Failed to delete. Please try again.');
      onUpdateTodo(todo); // Revert delete on error
    } finally {
      setIsProcessing(false);
    }
  };

  // Optimistic edit save
  const handleSaveEdit = async () => {
    const originalTodo = { ...todo };
    const updatedTodo = { ...todo, title: editTitle, description: editDescription };

    setIsProcessing(true);
    onUpdateTodo(updatedTodo); // Immediate UI update

    try {
      await updateTodo(todo.id, updatedTodo);
      setIsEditing(false);
    } catch (error) {
      console.error('Error saving todo edits:', error);
      onUpdateTodo(originalTodo); // Revert on error
      setError('Failed to save edits. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCancelEdit = () => {
    setEditTitle(todo.title);
    setEditDescription(todo.description);
    setIsEditing(false);
  };

  const statusDisplay = todo.status === 'completed' ? 'Completed' : 'Pending';

  return (
    <div className="flex items-center justify-between p-4 bg-white rounded-lg shadow-lg mb-4 hover:shadow-xl transition-shadow duration-200 ease-in-out">
      <div className="flex-1 text-center">
        {isEditing ? (
          <div>
            <input
              type="text"
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              className="mb-2 px-2 py-1 border rounded w-full text-gray-800"
              disabled={isProcessing}
            />
            <textarea
              value={editDescription}
              onChange={(e) => setEditDescription(e.target.value)}
              className="mb-2 px-2 py-1 border rounded w-full text-gray-800"
              disabled={isProcessing}
            />
            <div className="space-x-2">
              <button
                onClick={handleSaveEdit}
                className="px-4 py-2 rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none"
                disabled={isProcessing}
              >
                {isProcessing ? 'Saving...' : 'Save'}
              </button>
              <button
                onClick={handleCancelEdit}
                className="px-4 py-2 rounded-md text-white bg-gray-600 hover:bg-gray-700 focus:outline-none"
                disabled={isProcessing}
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <>
            <h4
              className={`text-2xl font-semibold text-gray-800 mb-2 ${
                todo.status === 'completed' ? 'line-through text-gray-500' : ''
              }`}
            >
              {todo.title || 'Untitled Task'}
            </h4>
            <p
              className={`text-gray-600 text-base mb-2 ${
                todo.status === 'completed' ? 'line-through text-gray-400' : ''
              }`}
            >
              {todo.description || 'No description available.'}
            </p>
            <p className={`text-sm font-medium ${todo.status === 'completed' ? 'text-green-500' : 'text-yellow-500'}`}>
              {statusDisplay}
            </p>
            {error && <p className="text-red-500 text-sm">{error}</p>}
          </>
        )}
      </div>

      <div className="flex flex-col space-y-2">
        {!isEditing && (
          <>
            <button
              onClick={handleUpdate}
              className={`px-4 py-2 rounded-md text-white ${
                todo.status === 'pending' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-green-600 hover:bg-green-700'
              } focus:outline-none`}
              disabled={isProcessing}
            >
              {isProcessing ? 'Updating...' : todo.status === 'pending' ? 'Mark as Completed' : 'Mark as Pending'}
            </button>

            <button
              onClick={() => setIsEditing(true)}
              className="px-4 py-2 rounded-md text-white bg-yellow-600 hover:bg-yellow-700 focus:outline-none"
              disabled={isProcessing}
            >
              Edit
            </button>
          </>
        )}
        <button
          onClick={handleDelete}
          className="px-4 py-2 rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none"
          disabled={isProcessing}
        >
          {isProcessing ? 'Deleting...' : 'Delete'}
        </button>
      </div>
    </div>
  );
};

export default TodoItem;
