import React from 'react';
import Navbar from './components/Navbar';
import TodoList from './components/TodoList';

function App() {
  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
      
      {/* Navbar - Sticky Header */}
      <Navbar />

      {/* Main Content */}
      <main className="flex-grow flex items-center justify-center py-10">
        <div className="w-full max-w-3xl bg-white shadow-lg rounded-lg overflow-hidden">
          
          {/* Header Section */}
          <div className="bg-indigo-600 text-white p-6 text-center">
            <h1 className="text-3xl font-semibold">Todo List</h1>
            <p className="mt-2 text-lg">Keep track of your tasks and stay organized.</p>
          </div>

          {/* Todo List */}
          <div className="p-8">
            <TodoList />
          </div>

          {/* Footer Section */}
          <div className="bg-gray-200 p-4 text-center">
            <p className="text-sm text-gray-600">© 2025 Your Todo App. All rights reserved.</p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-4">
        <div className="text-center text-sm">
          <p>&copy; 2025 Your Todos-App. All Rights Reserved.</p>
          <p>Made with ❤️ using React & Tailwind CSS</p>
          <p>Made with ❤️ Hard work of Javeria</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
